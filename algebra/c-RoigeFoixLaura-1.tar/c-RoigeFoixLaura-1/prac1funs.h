/* COGNOM1: ROIGÉ  COGNOM2: FOIX  NOM: LAURA  DNI: 47873311F */



void resTinf (int n, double **L, double *x, double *b);
void resTsup (int n, double **U, double *x, double *b);
void prodMatVec (int m, int n, double **A, double *x, double *y);
void prodMatMat (int m, int n, int p, double **A, double **B, double **C);
